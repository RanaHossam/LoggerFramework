//
//  LoggerFramework.h
//  LoggerFramework
//
//  Created by Rana Hossam on 1/30/20.
//  Copyright © 2020 Rana Hossam. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for LoggerFramework.
FOUNDATION_EXPORT double LoggerFrameworkVersionNumber;

//! Project version string for LoggerFramework.
FOUNDATION_EXPORT const unsigned char LoggerFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LoggerFramework/PublicHeader.h>


