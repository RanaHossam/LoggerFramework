//
//  Speakol.h
//  Speakol
//
//  Created by Yehia Beram on 12/17/19.
//  Copyright © 2019 Yehia Beram. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Speakol.
FOUNDATION_EXPORT double SpeakolVersionNumber;

//! Project version string for Speakol.
FOUNDATION_EXPORT const unsigned char SpeakolVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Speakol/PublicHeader.h>


